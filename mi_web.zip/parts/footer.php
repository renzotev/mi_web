        <footer>
            <div class="container">
                <div class="col-sm-4 col-sm-push-8">
                    <img src="img/logo-blanco.png" class="img-responsive logo-blanco">
                </div>
                <div class="col-sm-8 col-sm-pull-4">
                    <div class="address">
                        Ministerio de Trabajo y Promoción del Empleo<br />
                        Mesa de Partes: Av. Salaverry 655 - Jesús María - Central Telefónica: 630-6000 / 630-6030<br />
                        Horarios de Atención de la línea de Consultorios Laborales 0800-1-6872: 7:00 am a 4:30 pm en horario corrido<br />
                        Horarios de Atención para los Trabajadores del Hogar: Días domingo de 8:00 am a 5:00 pm - Calendario de Atención<br />
                        Horarios de Atención - Contáctenos a informes@trabajo.gob.pe
                    </div>
                </div>
            </div>
        </footer>   
        

        <script src="js/vendor/jquery-1.11.2.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/jquery.slides.min.js"></script>
        <script src="js/vendor/owl.carousel.min.js"></script>

        <script src="js/main.js"></script>
    </body>
</html>