<?php require_once 'parts/header.php'; ?>

<div class="breadcrumb-wrapper hidden">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="index.php">Inicio</a></li>
            <li class="active"><span>Charlas y Eventos</span></li>
        </ol>
    </div>
</div>

<div class="general-content">
    <div class="container">
        <ul class="list-images">
        	<li class="title"><h1>Charlas y Eventos</h1></li>
        	<li><a href="#"><img src="img/charla-1.jpg" clas="img-responsive"></a></li>
        	<li><a href="#"><img src="img/charla-1.jpg" clas="img-responsive"></a></li>
        	<li><a href="#"><img src="img/charla-1.jpg" clas="img-responsive"></a></li>
        	<li><a href="#"><img src="img/charla-1.jpg" clas="img-responsive"></a></li>
        	<li><a href="#"><img src="img/charla-1.jpg" clas="img-responsive"></a></li>
        	<li><a href="#"><img src="img/charla-1.jpg" clas="img-responsive"></a></li>
        	<li><a href="#"><img src="img/charla-1.jpg" clas="img-responsive"></a></li>
        </ul>
    </div>
</div>

<?php require_once 'parts/footer.php'; ?>