<?php require_once 'parts/header.php'; ?>

<div class="breadcrumb-wrapper hidden">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="index.php">Inicio</a></li>
            <li class="active"><span>Alta Dirección</span></li>
        </ol>
    </div>
</div>

<div class="general-content">
    <div class="container">
        <img src="img/puestos.png" class="aligncenter">
    </div>
</div>

<?php require_once 'parts/footer.php'; ?>