$(function(){
	$('#slides').slidesjs({
		width: 1140,
		height: 400,
		navigation: false,
		play: {
			auto: true,
			pauseOnHover: true
		}
	});
});
